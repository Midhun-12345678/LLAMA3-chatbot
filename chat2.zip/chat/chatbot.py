from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from transformers import pipeline
import json

# Initialize FastAPI app
app = FastAPI()

# Add CORS middleware to allow requests from any origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins (adjust as needed for production)
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Load the DistilBERT question-answering pipeline
qa_pipeline = pipeline("question-answering", model="distilbert-base-uncased-distilled-squad")

# Load Gritstone data from JSON (ensure this file is copied to the Docker container)
with open("gritstone technology data2.0.txt", "r") as f:
    gritstone_data = json.load(f)

# Mount the static directory for CSS and other static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Serve the HTML file at the root endpoint
@app.get("/", response_class=HTMLResponse)
async def get_html():
    with open("templates/index.html") as f:
        return HTMLResponse(content=f.read())

# Define the request model for user queries
class UserQuery(BaseModel):
    message: str

# Helper function to convert JSON data to a single context text for QA
def json_to_context(data):
    context = f"Company: {data['company']}\nMission: {data['mission']}\nValues: {', '.join(data['values'])}\n"
    context += "Services: " + " | ".join(
        [f"{service['category']} ({', '.join(service.get('technologies', []))})" if isinstance(service, dict) else service
         for service in data["services"]]) + "\n"
    context += "Industries: " + ", ".join(data["industries"]) + "\n"
    context += "Contact: " + " | ".join(
        [f"{country}: {info['address']}, Phone: {info['phone']}, Email: {info['email']}" 
         for country, info in data["contact"].items()]) + "\n"
    context += "Team: " + " | ".join([f"{member['name']} ({member['role']}): {member['experience']}" 
                                       for member in data["team"]])
    return context

# Prepare a single context string from JSON data
context = json_to_context(gritstone_data)

# Chat endpoint for QA
@app.post("/chat/")
async def chat(query: UserQuery):
    # Use DistilBERT to answer questions based on JSON data
    answer = qa_pipeline(question=query.message, context=context)
    return {"response": answer['answer']}
